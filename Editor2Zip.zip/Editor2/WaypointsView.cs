#if UNITY_EDITOR

using System;
using System.Collections.Generic;
using System.Linq;
using JetBrains.Annotations;
using Sirenix.OdinInspector;
using UI;
using UnityEditor;
using UnityEngine;

namespace GPS.Editor2
{
    public class WaypointsView : MonoBehaviour
    {
        public WayPointsSO WayPointsSo;

        private int StartIndex => Math.Max(IndexCenter - Range.x, 0);
        private int EndIndex => Math.Min(IndexCenter + Range.y, MaxIndex);

        private int MaxIndex => WayPointsSo.nodes.Count - 1;

        public Vector2Int Range = new Vector2Int(100, 100);

        [PropertyRange(0, "MaxIndex")] public int IndexCenter;

        public float RadiusGizmo = 1f;
        public float RadiusGizmo2 = 2f;
        public int Step = 100;
        public bool ShowSecondPriorityPoints = true;

        public Color ColorMain = Color.red;
        public Color ColorSecond = Color.magenta;

        public int FontSize = 30;
        public float IndexTextOffset = 5f;
        public float PositionTextOffset = 4f;

        private GUIStyle _style;

        public bool ShowIndices = true;
        public bool ShowCoordinates = true;

        [Header("Add point")] public Transform AddPointTransform;

        public NodeSelectionTool NodeSelectionTool;


        [Button]
        public void AddPoint()
        {
            WayPointNode point = new WayPointNode
            {
                position = new NodePosition(AddPointTransform.position),
                id = (uint)WayPointsSo.nodes.Count
            };
            WayPointsSo.nodes.Add(point);

            Debug.Log("Point added:" + point.position);
            EditorUtility.SetDirty(WayPointsSo);
        }


        [Button]
        public void Delete()
        {
            using (StateLogger _ = new StateLogger("Deletion. Nodes count", () => WayPointsSo.nodes.Count))
            {
                foreach (int index in NodeSelectionTool.SelectedIndices.OrderByDescending(i => i))
                    WayPointsSo.nodes.RemoveAt(index);
            }

            Dictionary<uint, uint> upd = new Dictionary<uint, uint>();
            foreach ((int index, WayPointNode node) in WayPointsSo.nodes.Enumerate())
            {
                if (node.id != (uint)index)
                    upd[node.id] = (uint)index;
                
                
            }

            foreach (WayPointNode node in WayPointsSo.nodes)
            {
                node.next = node.next
                    .Where(u => !NodeSelectionTool.SelectedIndices.Contains((int)u))
                    .Select(u => upd.TryGetValue(u, out uint u2) ? u2 : u)
                    .ToArray();
                node.id = upd.TryGetValue(node.id, out uint i2) ? i2 : node.id;
            }

            UpdateGrids();
            RemoveFarNextNodes();
        }

        // [Button]
        // private void TestPoint()
        // {
        //     int depID = GPSTracker.FindClosestPoint(AddPointTransform.position);
        //     Debug.Log("DepID:" + depID);
        //     NodePosition pos = GPSTracker.nodes[depID].position;
        //     //
        //     // _selected = pos;
        //     // Debug.Log("Selected:" + _selected);
        // }

        [Button]
        private void UpdateGrids()
        {
            using StateLogger _ = new StateLogger("WayPointsSO.grid", () => WayPointsSo.grid.Count);
            WayPointsSo.grid.Clear();

            foreach (WayPointNode wayPoint in WayPointsSo.nodes)
            {
                WayPointsSo.AddAreaID(wayPoint.id,
                    GPSTracker.GetAreaID(wayPoint));
            }

            EditorUtility.SetDirty(WayPointsSo);
        }

        public float FilterDistance = 1f;
        [SerializeField] private float NextSphereRadius = 0.5f;
        [SerializeField] private Color NextNodePointerColor = Color.yellow;

        [Button]
        private void RemoveFarNextNodes()
        {
            int removed = 0;
            using StateLogger _ = new StateLogger("Remove Far Next Nodes", () => removed);
            foreach (WayPointNode node in WayPointsSo.nodes)
            {
                Vector3 pos = node;
                int startCount = node.next.Length;
                node.next = node.next
                    .Where(next =>
                        ((WayPointsSo.nodes[(int)next]) - pos).sqrMagnitude <= FilterDistance * FilterDistance)
                    .ToArray();
                removed += startCount - node.next.Length;
            }

            EditorUtility.SetDirty(WayPointsSo);
        }

        [Button]
        private void RemoveUnusedNextNodes()
        {
            int removed = 0;
            using StateLogger _ = new StateLogger("Remove Unused Next Nodes", () => removed);
            foreach (WayPointNode node in WayPointsSo.nodes)
            {
                int startCount = node.next.Length;
                node.next = node.next
                    .Where(next => (int)next < WayPointsSo.nodes.Count)
                    .ToArray();
                removed += startCount - node.next.Length;
            }

            EditorUtility.SetDirty(WayPointsSo);
        }

        private bool _enabled;

        [ButtonGroup("Edit Mode"), DisableIf("_enabled"), UsedImplicitly]
        private void Enable()
        {
            _enabled = true;
            SceneView.duringSceneGui += HandleSceneGui;
        }


        [ButtonGroup("Edit Mode"), EnableIf("_enabled"), UsedImplicitly]
        private void Disable()
        {
            _enabled = false;
            SceneView.duringSceneGui -= HandleSceneGui;
        }

        [SerializeField] private float FillStep = 5;


        private void HandleSceneGui(SceneView sceneView)
        {
            Event e = Event.current;
            if (e == null)
                return;
            if (e.type == EventType.MouseDown && e.button == 0)
            {
                if (Physics.Raycast(HandleUtility.GUIPointToWorldRay(e.mousePosition), out RaycastHit hit))
                {
                    Undo.RecordObject(WayPointsSo, "Waypoints SO change");
                    Undo.RecordObject(Holder, "Holder indices change");
                    TryFillWithPoints(hit.point + UpOffset);
                }

                e.Use();
            }
        }

        [SerializeField] private StackHolder Holder;
        [SerializeField] private Vector3 UpOffset = new Vector3(0, 3, 0);

        private void TryFillWithPoints(Vector3 newPoint)
        {
            if (!Holder.Last.HasValue)
            {
                WayPointNode last = new WayPointNode
                {
                    position = new NodePosition(newPoint), id = (uint)WayPointsSo.nodes.Count,
                    next = Array.Empty<uint>()
                };
                WayPointsSo.nodes.Add(last);
                Holder.Add(last.id);
                return;
            }

            Vector3 lastPoint = WayPointsSo.nodes[Holder.Last.Value];
            Vector3 delta = newPoint - lastPoint;
            Vector3 dir = delta.normalized * FillStep;

            int steps = Mathf.CeilToInt(delta.magnitude / FillStep) - 1;

            for (int i = 1; i < steps; i++)
            {
                WayPointNode wayPointNode = new WayPointNode
                {
                    position = new NodePosition(lastPoint + dir * i),
                    id = (uint)WayPointsSo.nodes.Count,
                    next = Array.Empty<uint>()
                };
                WayPointsSo.nodes[Holder.Last.Value].next = new[] { wayPointNode.id };
                WayPointsSo.nodes.Add(wayPointNode);
                Holder.Add(wayPointNode.id);
            }

            WayPointNode newPointNode = new WayPointNode
            {
                position = new NodePosition(newPoint), id = (uint)WayPointsSo.nodes.Count, next = Array.Empty<uint>()
            };
            if (Holder.Last.HasValue)
                WayPointsSo.nodes[Holder.Last.Value].next = new[] { newPointNode.id };
            WayPointsSo.nodes.Add(newPointNode);
            Holder.Add(newPointNode.id);
            EditorUtility.SetDirty(WayPointsSo);
        }


        private void OnValidate()
        {
            _style = new GUIStyle
            {
                fontSize = FontSize,
                normal =
                {
                    textColor = ColorMain
                },
                alignment = TextAnchor.MiddleCenter
            };
        }

        private void OnDrawGizmos()
        {
            DrawNodes();
            DrawConnections();
        }

        private void DrawConnections()
        {
            Vector3 arrowOffset = Vector3.up * .4f;
            foreach (WayPointNode node in EnumerateMainNodes())
            {
                Vector3 pos = node;
                foreach (uint u in node.next)
                {
                    Vector3 nextPos = WayPointsSo[u];
                    Gizmos.color = NextNodePointerColor;
                    Gizmos.DrawLine(pos, nextPos);
                    Vector3 offset = pos + (nextPos - pos) * .8f;

                    Gizmos.DrawLine(nextPos, offset + arrowOffset);
                    Gizmos.DrawLine(nextPos, offset - arrowOffset);
                }
            }
        }

        private void DrawNodes()
        {
            foreach (WayPointNode node in EnumerateMainNodes())
            {
                Gizmos.color = NodeSelectionTool.SelectedIndices.Contains((int)node.id)
                    ? NodeSelectionTool.SelectedNodesColor
                    : ColorMain;
                Gizmos.DrawCube(node, Vector3.one * RadiusGizmo2);

                if (ShowIndices)
                {
                    Handles.color = ColorMain;
                    string text1 = $"{node.id}";
                    Handles.Label(node + Vector3.up * IndexTextOffset, text1, _style);
                }

                if (ShowCoordinates)
                {
                    Handles.color = ColorSecond;
                    string text2 = $"Pos: {(Vector3)node}";
                    Handles.Label(node + Vector3.up * PositionTextOffset, text2, _style);
                }
            }

            if (ShowSecondPriorityPoints)
            {
                Gizmos.color = ColorSecond;
                foreach (WayPointNode node in EnumerateSecondaryNodes())
                {
                    Gizmos.DrawWireSphere(node, RadiusGizmo);
                }
            }
        }


        public IEnumerable<WayPointNode> EnumerateMainNodes()
        {
            List<WayPointNode> points = WayPointsSo.nodes;

            for (int i = StartIndex; i < EndIndex; i++)
                if (i % Step == 0)
                    yield return points[i];
        }

        private IEnumerable<WayPointNode> EnumerateSecondaryNodes()
        {
            List<WayPointNode> points = WayPointsSo.nodes;

            for (int i = StartIndex; i < EndIndex; i++)
                if (i % Step != 0)
                    yield return points[i];
        }
    }
}

#endif