﻿#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEngine;

namespace GPS.Editor2
{
    public class StackHolder : MonoBehaviour
    {
        [SerializeField] private List<int> Indices = new List<int>();
        public int? Last => Indices.Count > 0 ? (int?)Indices[Indices.Count - 1] : null;
        public void Add(uint u) => Indices.Add((int)u);
    }
}
#endif