﻿#if UNITY_EDITOR
using System.Collections.Generic;
using System.Linq;
using _Car_Parking.Scripts.Other.Helpers;
using Sirenix.OdinInspector;
using UnityEditor;
using UnityEngine;

namespace GPS.Editor2
{
    public class NodeSelectionTool : MonoBehaviour
    {
        private bool _selecting;
        private Vector2 _lastMousePos;
        private Vector2 _startMousePos;
        [SerializeField] private Color SelectionColor;
        public Color SelectedNodesColor;
        private Texture2D _white;
        private Texture2D White => _white ? _white : CreateWhiteTexture();
        public WaypointsView WaypointsView;

        private Texture2D CreateWhiteTexture()
        {
            Texture2D t = new Texture2D(1, 1);
            t.SetPixel(1, 1, SelectionColor);
            t.Apply();
            _white = t;
            return _white;
        }

        private void OnValidate()
        {
            _white = null;
        }

        private bool _selectionToolInUse;

        [ButtonGroup("Selection Tool"), Button, DisableIf("_selectionToolInUse")]
        private void SelectNodes()
        {
            SceneView.duringSceneGui += SelectNodes;
            _selectionToolInUse = true;
        }

        [ButtonGroup("Selection Tool"), Button]
        private void RemoveSelection()
        {
            SelectedIndices.Clear();
        }


        private bool _moveToolEnabled;

        [ButtonGroup("Move Tool"), DisableIf("_moveToolEnabled")]
        private void UseMoveTool()
        {
            if (SelectedIndices.Count == 0)
                return;
            _moveToolEnabled = true;
            if (!_handle)
                _handle = new GameObject("Move Nodes Handle");
            _startSelectedPoint = Vector3.zero;

            _startPositions.Clear();
            foreach (int selectedIndex in SelectedIndices)
            {
                _startSelectedPoint += WaypointsView.WayPointsSo[selectedIndex];
                _startPositions[selectedIndex] = WaypointsView.WayPointsSo[selectedIndex];
            }

            _startSelectedPoint /= SelectedIndices.Count;

            _handle.transform.position = _startSelectedPoint;

            SceneView.duringSceneGui -= MoveSelectedNodes;
            SceneView.duringSceneGui += MoveSelectedNodes;
            Debug.Log("Started moving nodes...");
            Selection.activeTransform = _handle.transform;
        }

        [ButtonGroup("Move Tool"), EnableIf("_moveToolEnabled")]
        private void StopUseMoveTool()
        {
            _moveToolEnabled = false;
            SceneView.duringSceneGui -= MoveSelectedNodes;
            Debug.Log("Ended moving nodes...");
        }

        private bool _connectToolEnabled;

        private bool _connect;

        private string ConnectText => _connect ? "Connect" : "Disconnect";

        [ButtonGroup("Connection Tool"), LabelText("ConnectText")]
        private void SwitchConnectionTool()
        {
            _connect = !_connect;
        }

        [ButtonGroup("Connection Tool"), DisableIf("_connectToolEnabled")]
        private void UseConnectionTool()
        {
            _connectToolEnabled = true;
            SceneView.duringSceneGui -= ConnectSelectedNodes;
            SceneView.duringSceneGui += ConnectSelectedNodes;
        }

        [ButtonGroup("Connection Tool"), EnableIf("_connectToolEnabled")]
        private void StopUseConnectionTool()
        {
            _connectToolEnabled = false;
            SceneView.duringSceneGui -= ConnectSelectedNodes;
        }


        private int? _nodeToConnect;
        [SerializeField] private float ConnectRadius;

        private void ConnectSelectedNodes(SceneView sceneView)
        {
            Event e = Event.current;
            Handles.BeginGUI();
            string text = _nodeToConnect.HasValue ? $"Select second node..." : "Select node...";
            GUI.Label(new Rect(0, 0, 200, 100), text);
            Handles.EndGUI();
            if (e == null)
                return;
            if (e.type != EventType.MouseDown || e.button != 2)
                return;
            (WayPointNode, float) tuple = WaypointsView.EnumerateMainNodes()
                .Select(n => (n,
                    (HandleUtility.WorldToGUIPoint(n.position) - e.mousePosition).sqrMagnitude))
                .OrderBy(n => n.sqrMagnitude)
                .FirstOrDefault();

            if (tuple == default)
                return;
            (WayPointNode node, float sqrMagnitude) = tuple;
            if (sqrMagnitude < ConnectRadius * ConnectRadius)
            {
                if (_nodeToConnect.HasValue)
                {
                    uint[] newNext = WaypointsView.WayPointsSo[_nodeToConnect.Value].next;
                    if (_connect)
                    {
                        newNext = newNext == null
                            ? new[] { node.id }
                            : newNext.Append(node.id).Distinct().ToArray();
                        Debug.Log($"Connected {_nodeToConnect.Value} -> {node.id}");
                    }
                    else
                    {
                        newNext = newNext == null
                            ? new uint[] { }
                            : newNext.Where(i => i != node.id).Distinct().ToArray();
                        Debug.Log($"Disconnected {_nodeToConnect.Value} X {node.id}");
                    }

                    WaypointsView.WayPointsSo[_nodeToConnect.Value].next = newNext;

                    _nodeToConnect = null;
                }
                else
                {
                    _nodeToConnect = (int)node.id;
                }
            }

            e.Use();
        }

        private GameObject _handle;

        private readonly Dictionary<int, Vector3> _startPositions = new Dictionary<int, Vector3>();

        private void MoveSelectedNodes(SceneView obj)
        {
            Vector3 delta = _handle.transform.position - _startSelectedPoint;
            foreach (int selectedIndex in SelectedIndices)
            {
                _startPositions[selectedIndex] += delta;
                WaypointsView.WayPointsSo[selectedIndex].position = new NodePosition(_startPositions[selectedIndex]);
            }

            _startSelectedPoint = _handle.transform.position;
        }

        private void SelectNodes(SceneView obj)
        {
            Event e = Event.current;
            if (_selecting)
            {
                if (e != null)
                    _lastMousePos = e.mousePosition;
                Handles.BeginGUI();
                Vector2 min = Vector2.Min(_startMousePos, _lastMousePos);
                Vector2 max = Vector2.Max(_startMousePos, _lastMousePos);
                var c = GUI.color;
                GUI.color = SelectionColor;
                GUI.DrawTexture(new Rect(min, max - min), White);
                GUI.color = c;

                Handles.EndGUI();
            }

            if (e == null)
                return;
            if (e.type == EventType.MouseDown && e.button == 1)
            {
                if (!_selecting)
                {
                    _selecting = true;
                    _startMousePos = e.mousePosition;
                    e.Use();
                }
            }

            if (e.type == EventType.MouseUp && e.button == 1)
            {
                if (_selecting)
                    SelectUnderlyingNodes();
                _selecting = false;
                _selectionToolInUse = false;
                SceneView.duringSceneGui -= SelectNodes;
                e.Use();
            }
        }

        public List<int> SelectedIndices;
        private Vector3 _startSelectedPoint;

        private void SelectUnderlyingNodes()
        {
            SelectedIndices.Clear();
            Vector2 min = Vector2.Min(_startMousePos, _lastMousePos);
            Vector2 max = Vector2.Max(_startMousePos, _lastMousePos);
            Rect rect = new Rect(min, max - min);

            foreach (WayPointNode node in WaypointsView.EnumerateMainNodes().Where(node =>
                         rect.Contains(HandleUtility.WorldToGUIPoint(node))))
            {
                SelectedIndices.Add((int)node.id);
            }
        }
    }
}
#endif